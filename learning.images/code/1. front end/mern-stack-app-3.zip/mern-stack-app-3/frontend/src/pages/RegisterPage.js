const RegisterPage = () => {
  return <p>This is a register page</p>;
};

export default RegisterPage;

