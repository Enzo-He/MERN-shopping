const CartPage = () => {
  return <p>This is a cart page</p>;
};

export default CartPage;

