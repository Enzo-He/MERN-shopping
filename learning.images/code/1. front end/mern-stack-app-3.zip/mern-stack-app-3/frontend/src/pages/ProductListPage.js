const ProductListPage = () => {
  return <p>This is a product list page</p>;
};

export default ProductListPage;

