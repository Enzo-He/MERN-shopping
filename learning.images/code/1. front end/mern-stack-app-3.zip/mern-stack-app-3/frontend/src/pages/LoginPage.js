const LoginPage = () => {
  return <p>This is a login page</p>;
};

export default LoginPage;

