const UserOrderDetailsPage = () => {
  return <p>This is a user order details page</p>;
};

export default UserOrderDetailsPage;

