const UserCartDetailsPage = () => {
  return <p>This is a user cart details page</p>;
};

export default UserCartDetailsPage;

