const UserProfilePage = () => {
  return <p>This is a user profile page</p>;
};

export default UserProfilePage;

