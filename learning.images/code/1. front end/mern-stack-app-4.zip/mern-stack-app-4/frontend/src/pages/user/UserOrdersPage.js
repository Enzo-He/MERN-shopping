const UserOrdersPage = () => {
  return <p>This is a user orders page</p>;
};

export default UserOrdersPage;

