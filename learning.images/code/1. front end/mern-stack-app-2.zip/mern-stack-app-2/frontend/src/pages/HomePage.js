const HomePage = () => {
  return <p>This is a home page</p>;
};

export default HomePage;

