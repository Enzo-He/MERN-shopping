const FooterComponent = () => {
    return <p>This is a footer</p>
}

export default FooterComponent
