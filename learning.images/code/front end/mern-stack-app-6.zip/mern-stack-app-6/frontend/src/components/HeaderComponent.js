const HeaderComponent = () => {
    return <p>This is a header</p>
}

export default HeaderComponent
