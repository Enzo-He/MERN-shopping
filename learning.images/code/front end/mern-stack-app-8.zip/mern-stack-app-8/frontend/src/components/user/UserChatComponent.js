const UserChatComponent = () => {
return <p>This is a user chat component</p>
}

export default UserChatComponent
