const AdminProductsPage = () => {
  return <p>This is a products page</p>;
};

export default AdminProductsPage;

