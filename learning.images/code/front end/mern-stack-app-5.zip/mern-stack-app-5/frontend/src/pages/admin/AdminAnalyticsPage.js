const AdminAnalyticsPage = () => {
  return <p>This is an analytics page</p>;
};

export default AdminAnalyticsPage;

