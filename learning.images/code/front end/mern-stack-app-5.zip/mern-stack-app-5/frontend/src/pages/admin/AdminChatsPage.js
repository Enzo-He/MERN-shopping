const AdminChatsPage = () => {
  return <p>This is a chats page</p>;
};

export default AdminChatsPage;

