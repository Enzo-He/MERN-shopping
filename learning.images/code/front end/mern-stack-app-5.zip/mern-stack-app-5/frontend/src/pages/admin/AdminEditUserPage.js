const AdminEditUserPage = () => {
  return <p>This is an edit user page</p>;
};

export default AdminEditUserPage;

